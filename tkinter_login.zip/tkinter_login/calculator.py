import tkinter
from playsound import playsound
import threading
from functools import partial
def print_number(number):
    threading.Thread(playsound("beep.mp3")).start()
    output_textbox.configure(state=tkinter.NORMAL)
    output_textbox.insert(tkinter.END, str(number))
    output_textbox.configure(state=tkinter.DISABLED)

def evaluate():
    expression= output_textbox.get()
    result = eval(expression)
    output_textbox.configure(state=tkinter.NORMAL)
    output_textbox.delete(0, len(expression))
    output_textbox.insert(tkinter.END, result)
    output_textbox.configure(state=tkinter.DISABLED)

def clear(eve):
    output_textbox.configure(state=tkinter.NORMAL)
    output_textbox.delete(0, len(output_textbox.get()))
    output_textbox.configure(state=tkinter.DISABLED)


window = tkinter.Tk()
window.title("Calculator")
window.geometry("400x400")

window.bind("<Key-BackSpace>", clear)


window.grid_rowconfigure(0, weight=1)
window.grid_columnconfigure(0, weight=1)

output_frame = tkinter.Frame(window, width=400, height=100, bg='#f9ccef')
output_frame.grid(row=0, column=0, sticky="news")

button_frame = tkinter.Frame(window, width=400, height=300, bg='#c585b7')
button_frame.grid(row=1, column=0, sticky="news")

for i in range(4):
    button_frame.grid_rowconfigure(i, weight=1)
    button_frame.grid_columnconfigure(i, weight=1)

output_textbox = tkinter.Entry(output_frame, font=("Calibri", 30),
                               state=tkinter.DISABLED, disabledbackground='#f9ccef', bg='#f9ccef', fg='#000000')
output_textbox.grid(row=0, column=0, sticky="news", padx=10, pady=10)

button_one = tkinter.Button(button_frame, font=("Calibri", 20), text='1', width=6, bg='#aa98a9', fg='#000000')
button_one.configure(command=partial(print_number, 1))
button_one.grid(row=0, column=0, sticky="news", padx=5, pady=5)

button_two = tkinter.Button(button_frame, font=("Calibri", 20), text='2', width=6, bg='#aa98a9', fg='#000000')
button_two.configure(command=partial(print_number, 2))
button_two.grid(row=0, column=1, sticky="news", padx=5, pady=5)

button_three = tkinter.Button(button_frame, font=("Calibri", 20), text='3', width=6, bg='#aa98a9', fg='#000000')
button_three.configure(command=partial(print_number, 3))
button_three.grid(row=0, column=2, sticky="news", padx=5, pady=5)

button_four = tkinter.Button(button_frame, font=("Calibri", 20), text='4', width=6, bg='#aa98a9', fg='#000000')
button_four.configure(command=partial(print_number, 4))
button_four.grid(row=1, column=0, sticky="news", padx=5, pady=5)

button_five = tkinter.Button(button_frame, font=("Calibri", 20), text='5', width=6, bg='#aa98a9', fg='#000000')
button_five.configure(command=partial(print_number, 5))
button_five.grid(row=1, column=1, sticky="news", padx=5, pady=5)

button_six = tkinter.Button(button_frame, font=("Calibri", 20), text='6', width=6, bg='#aa98a9', fg='#000000')
button_six.configure(command=partial(print_number, 6))
button_six.grid(row=1, column=2, sticky="news", padx=5, pady=5)

button_seven = tkinter.Button(button_frame, font=("Calibri", 20), text='7', width=6, bg='#aa98a9', fg='#000000')
button_seven.configure(command=partial(print_number, 7))
button_seven.grid(row=2, column=0, sticky="news", padx=5, pady=5)

button_eight = tkinter.Button(button_frame, font=("Calibri", 20), text='8', width=6, bg='#aa98a9', fg='#000000')
button_eight.configure(command=partial(print_number, 8))
button_eight.grid(row=2, column=1, sticky="news", padx=5, pady=5)

button_nine = tkinter.Button(button_frame, font=("Calibri", 20), text='9', width=6, bg='#aa98a9', fg='#000000')
button_nine.configure(command=partial(print_number, 9))
button_nine.grid(row=2, column=2, sticky="news", padx=5, pady=5)

button_zero = tkinter.Button(button_frame, font=("Calibri", 20), text='0', width=6, bg='#aa98a9', fg='#000000')
button_zero.configure(command=partial(print_number, 0))
button_zero.grid(row=3, column=1, sticky="news", padx=5, pady=5)

button_plus = tkinter.Button(button_frame, font=("Calibri", 20), text='+', width=6, bg='#aa98a9', fg='#000000')
button_plus.configure(command=partial(print_number, "+"))
button_plus.grid(row=0, column=3, sticky="news", padx=5, pady=5)

button_minus = tkinter.Button(button_frame, font=("Calibri", 20), text='-', width=6, bg='#aa98a9', fg='#000000')
button_minus.configure(command=partial(print_number, "-"))
button_minus.grid(row=1, column=3, sticky="news", padx=5, pady=5)

button_multiply = tkinter.Button(button_frame, font=("Calibri", 20), text='x', width=6, bg='#aa98a9', fg='#000000')
button_multiply.configure(command=partial(print_number, "*"))
button_multiply.grid(row=2, column=3, sticky="news", padx=5, pady=5)

button_divide = tkinter.Button(button_frame, font=("Calibri", 20), text='/', width=6, bg='#aa98a9', fg='#000000')
button_divide.configure(command=partial(print_number, "/"))
button_divide.grid(row=3, column=3, sticky="news", padx=5, pady=5)

button_equal = tkinter.Button(button_frame, font=("Calibri", 20), text='=', width=6, bg='#aa98a9', fg='#000000')
button_equal.configure(command=evaluate)
button_equal.grid(row=3, column=2, sticky="news", padx=5, pady=5)

button_dot = tkinter.Button(button_frame, font=("Calibri", 20), text='.', width=6, bg='#aa98a9', fg='#000000')
button_dot.configure(command=partial(print_number, "."))
button_dot.grid(row=3, column=0, sticky="news", padx=5, pady=5)

window.mainloop()
